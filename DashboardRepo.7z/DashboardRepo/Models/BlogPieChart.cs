﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DashboardRepo.Models
{
    public class BlogPieChart
    {
        [Key]
        public string CategoryName { get; set; }
        public int? PostCount { get; set; }
    }
}
