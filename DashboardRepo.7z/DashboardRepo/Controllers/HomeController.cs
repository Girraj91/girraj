﻿
using System;
using System.Collections.Generic;
using System.Web.Mvc;
using System.Linq;
using Newtonsoft.Json;


namespace ASPNET_MVC_ChartsDemo.Controllers
{
	public class HomeController : Controller
	{
		private DataPointsDBEntities _db = new DataPointsDBEntities();z
		public ActionResult Index()
		{
			try
			{
				ViewBag.DataPoints = JsonConvert.SerializeObject(_db.Points.ToList(), _jsonSetting);

				return View();
			}
			catch (System.Data.Entity.Core.EntityException)
			{
				return View("Error");
			}
			catch (System.Data.SqlClient.SqlException)
			{
				return View("Error");
			}
		}
		JsonSerializerSettings _jsonSetting = new JsonSerializerSettings() { NullValueHandling = NullValueHandling.Ignore };
	}
}
