﻿using CrudApplication.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CrudApplication.Controllers
{
    public class EmployeeController : Controller
    {

        private readonly ApplicationDbContext context;

        public EmployeeController(ApplicationDbContext _context)
        {
            context = _context;
        }
        public IActionResult Index()
        {
           
            return View();
        }

        [HttpPost]
        public IActionResult Index()
        {
          
            return View();
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Employee model)
        {
            var emp = new Employee()
            {

                FirstName = model.FirstName,
                LastName = model.LastName,
                Gender = model.Gender,
                Course = model.Course,
                Email = model.Email,
                Mobile = model.Mobile,
                Password = model.Password,
                ConfirmPassword = model.ConfirmPassword,
            };
            context.Employees.Add(emp);
            context.SaveChanges();
            return RedirectToAction("Index");

        }
        public IActionResult Delete(int id)
        {
            var emp = context.Employees.SingleOrDefault(e => e.Id == id);

            context.Employees.Remove(emp);
            context.SaveChanges();
            return RedirectToAction("Index");
        }
        public IActionResult Update(int id)
        {
            var upd = context.Employees.SingleOrDefault(e => e.Id == id);

            return View(upd);
        }
        [HttpPost]
        public IActionResult Update(Employee model)
        {
            Employee emp = new Employee()
            {
                Id = model.Id,
                FirstName = model.FirstName,
                LastName = model.LastName,
                Gender = model.Gender,
                Course = model.Course,
                Email = model.Email,
                Mobile = model.Mobile,
                Password = model.Password,
                ConfirmPassword = model.ConfirmPassword,

            };

            context.Employees.Update(emp);
            context.SaveChanges();
            return RedirectToAction("Index");
        }

    }
}