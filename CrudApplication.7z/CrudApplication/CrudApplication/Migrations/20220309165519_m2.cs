﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CrudApplication.Migrations
{
    public partial class m2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Employees",
                columns: new[] { "Id", "ConfirmPassword", "Course", "Email", "FirstName", "Gender", "LastName", "Mobile", "Password" },
                values: new object[] { 1, "233444", "java", "amitc@chetu.com", "Amit", "male", "Chaurasiya", "216724284324", "233444" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Employees",
                keyColumn: "Id",
                keyValue: 1);
        }
    }
}
